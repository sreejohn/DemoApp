import React from 'react';
import { connect } from 'react-redux';
import { fetchPhones, fetchCategories } from '../actions/Phones';
import { getPhones } from '../selectors/Phones';
import { Link } from 'react-router';
import R from 'ramda';
import { loadMore, addPhoneToBasket } from '../actions/Phones';
import { Grid, Image, Card, CardContent } from 'semantic-ui-react';
import $ from 'jquery';

import { search } from './search.png';
class Phones extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            phones: this.props.phones,
            filteredphones: this.props.phones,
            q: ''
        };

        this.filterList = this.filterList.bind(this);
        this.onChange = this.onChange.bind(this);
    }

    componentWillReceiveProps(nextProps) {
        this.setState(
            {
                phones: nextProps.phones,
                filteredphones: nextProps.phones
            },
            () => this.filterList()
        );
    }

    onChange(event) {
        const q = event.target.value.toLowerCase();
        this.setState({ q }, () => this.filterList());
    }

    filterList() {
        let phones = this.state.phones;
        let q = this.state.q;
        if (phones.length > 30) {
            window.removeEventListener("scroll", this.props.loadMore);
        }
        phones = phones.filter(function (user) {
            // console.log(q + "user::" + user.name+"phones"+phones.length)
            return user.name.toLowerCase().indexOf(q) != -1; // returns true or false
        });
        this.setState({ filteredphones: phones });
    }
    componentDidMount() {
        this.props.fetchPhones();
        this.props.fetchCategories();
        if (this.props.phones.length < 10) {
        window.onscroll =
            window.addEventListener("scroll", this.props.loadMore);
        }
    }



    componentWillUnmount() {
        // remove the lazyLoad method
        window.removeEventListener("scroll", this.props.loadMore);
    }


    ViewDetails(id) {
        window.location.href = "/Phones/" + id;
    }


    render() {
        const { phones, loadMore } = this.props;
        //const { addPhoneToBasket } = this.props;
        var isMobile = /iPhone|iPod|Android/i.test(navigator.userAgent);
        var marginTop1 = "0%";
        var marginRight1 = "0%";
        if (!isMobile) {
            marginTop1 = "-1%";
            marginRight1 = "10%";
        }
        return (
            <div>
                <div id="navbar" style={{ marginTop: marginTop1 }}>
                    <form action="" style={{ float: "right", marginRight: marginRight1 }}>
                        <input type="search" autoFocus="true" placeholder="" autoComplete="off" onChange={this.onChange} value={this.state.q} />
                        <i class="fa fa-search"></i>
                    </form>
                </div>


                <div className="row">
                    <br></br><br></br>
                    <br></br>
                    {this.state.filteredphones.map((phone, index) => {
                        const shortDesc = `${R.take(60, phone.description)}...`;
                        return <div id="myTable" className="column11"><div className='col-sm-4 col-lg-4 col-md-4 book-list' key={index} style={{ padding: "0px" }}>
                            <div className="thumbnail">
                                <img className='img-thumbnail'
                                    src={phone.image}
                                    alt={phone.name}
                                />
                            </div>
                            <div className="caption" onClick={(event) => this.ViewDetails(phone.id)} style={{ height: "24px" }} >

                                <Link to={`./Phones/${phone.id}`}>
                                    <p className="textname">{phone.name}</p>
                                </Link>
                            </div>
                            <div style={{ height: "10px" }}></div>
                        </div></div>
                    })}
                </div>

                <button className="loadmore" style={{ border: "none" }}
                    onClick={loadMore}>
                    Load More
                    </button>

            </div>

        )
    };
};

const mapDispatchToProps = (dispatch) => ({
    fetchPhones: () => dispatch(fetchPhones()),
    loadMore: () => dispatch(loadMore()),
    // addPhoneToBasket: (id) => dispatch(addPhoneToBasket(id)),
    fetchCategories: () => dispatch(fetchCategories())
});
//ownProps are available here because this component is defined directly on route.
//child componenets must include compose withRoutes
const mapStateToProps = (state, ownProps) => ({
    phones: getPhones(state, ownProps)
});

export default connect(mapStateToProps, mapDispatchToProps)(Phones);
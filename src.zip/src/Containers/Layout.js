import React from 'react';
import { SideBar } from './SideBar';
import { Container } from 'semantic-ui-react'
import { search } from './search.png';
const Layout = ({ children }) => {
    return (
        <div >
            <Container style={{ paddingLeft: "15px", paddingTop: "1%" }}>
                {children}

            </Container>
        </div>
    )
};

export default Layout;